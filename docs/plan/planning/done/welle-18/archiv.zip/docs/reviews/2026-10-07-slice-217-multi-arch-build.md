# Review-Report: slice-217 — 2026-10-07

**Review-Art:** Code-Review — geprüft wird der Diff gegen Slice-Plan, ADR-0043, SPEC-DIST-001 und
die Hard Rules (Modul 10). Unabhängiger Lauf in frischem Kontext, nicht der Autor; keine
DoD-Verifikation (Verifier, Modul 11).

**Gegenstand:** Commit-Range `9534afe..c5533df` — Inhalt in `c5533df` (Dockerfile, Makefile,
`tools/image-multiarch.sh`, `tools/multiarch-check.sh`, `tools/image-test.sh`, Guard-Liste,
Gate-Index, `.gitignore`).

**Skill:** `.harness/skills/reviewer.md` @ `e6917e3` · <!-- d-check:ignore -->
**Modell:** claude-opus-5-5 · **Datum:** 2026-10-07

> **Zitier-Form** *(Norm, kein Ausfüll-Hinweis)*. Dieser Report friert ein; was er zitiert, bewegt
> sich weiter. Deshalb: **Kennung, nicht Adresse** — `slice-<Kennung>` statt seines
> Lifecycle-Pfads, `make <target>` statt eines Links auf die Sensor-Datei, eine Baseline-Stelle als
> **Tag + Pfad in Inline-Code** statt als Link. Ein `pfad`-Feld auf den **geprüften Gegenstand**
> ist davon nicht betroffen — es zitiert den Stand des Laufs und darf ihn festhalten.

**Eingangs-Kontext:**

- slice-217 (§1–§4, §6, §8), slice-218 (§1–§3), welle-18 (Welle-Plan)
- ADR-0043 (`Accepted`), SPEC-DIST-001, AC-FA-DIST-001, AC-QA-03
- `AGENTS.md` §3 (Hard Rules), §6 Schritt 4 (Plan-Änderung vor Code)
- frühere Findings am Bereich: Review slice-216 (F-4: Fitness Function nennt `make image-test`)
- Bestand: `.github/workflows/release.yml`, `.claude/hooks/pretooluse-command-guard.sh` (Selbsttest)

**Eigene Nachmessung** (Mess-Regel 1, Geltungsbereich): dieser Host `x86_64`, Docker 29.8.2, buildx
0.37.1, Builder `a-check-multiarch-cec9f139f45e` (BuildKit 0.33.1), **keine** arm64-Emulation;
eigene Registry `registry:2` auf Port 5187 (danach entfernt), Kopie per `skopeo copy --all`.
Mutationen am OCI-Archiv per Skript im Scratchpad (Index/Manifest/Config neu gehasht, `index.json`
nachgezogen). Gemessen wird `tools/multiarch-check.sh` gegen **BuildKit-förmige** und
**handgebaute** Archive — nicht gegen andere Exporter (`docker save`, `skopeo`-Archive).

| Probe | Ergebnis (Meldung) |
|---|---|
| `make image-multiarch VERSION=9.9.9-rev` | Exit 0, Index `46d6b58a…`, beide Plattformen, ELF 62/183 |
| Prüfung mit falscher Version | rot — „linux/amd64: Versions-Label '9.9.9-rev', erwartet '1.2.3'" |
| Index nur amd64 | rot — „Plattformen 'linux/amd64'" |
| Index amd64 doppelt + arm64 | rot — „Plattformen 'linux/amd64 linux/amd64 linux/arm64'" |
| Attestierungs-Eintrag ergänzt | rot — „der Index führt 'unknown/unknown'" |
| arm64-Eintrag zeigt auf das amd64-Manifest | rot — „linux/arm64: Config sagt linux/amd64" |
| arm64-Manifest mit amd64-Binary-Layer | rot — „linux/arm64: Binary hat ELF e_machine '62', erwartet '183'" |
| Feldreihenfolge `digest` vor `mediaType` | rot — „Plattformen 'linux/amd64'" (Split greift nicht, fail-closed) |
| Index eingerückt (Whitespace) | grün — korrekt, `blob()` entfernt Whitespace |
| Layer unkomprimiert / Binary nicht im letzten Layer | rot, Exit 2 — Meldung von `tar`, nicht vom Prüfer |
| **arm64-Eintrag mit Array-Feld (`urls` bzw. `platform.os.features`) + dritter Eintrag `linux/s390x`** | **grün** — „ok — … mit genau: linux/amd64 linux/arm64" (siehe F-2) |
| Dockerfile ohne `GOOS`/`GOARCH` (Kopie im Scratchpad) | rot — „linux/arm64: Binary hat ELF e_machine '62', erwartet '183'" |
| `make image-test-ref` mit Index-Digest aus der Registry | Exit 0 |
| `make image-test-ref` mit arm64-Manifest-Digest | rot — „ELF e_machine 183, Host x86_64 erwartet 62" |
| `make image-test-ref` ohne `IMAGE_REF` | Exit 2 — „IMAGE_REF=<tag\|digest> fehlt" |
| Guard-Liste ohne die zwei neuen Targets (Kopie, Selbsttest aus der Repo-Wurzel) | rot — „Pruef-Target 'image-multiarch' fehlt in der GATES-Liste" (und `image-test-ref`) |
| `make guard-selftest`, `make doc-targets`, `make gates`, `make doc-check` | Exit 0 (Ausgabe in Datei, Exit-Code getrennt) |
| `make doc-structure` (Teil von `make verify`) | rot, Exit 2 — ein Befund `section-cell-oversized` an `harness/README.md:93` (F-5) |
| `docker buildx imagetools inspect moby/buildkit:v0.33.1` | Index-Digest `cec9f139…` = Pin im Makefile |

---

## Findings

| ID | Kategorie | Befund | Quelle | Pfad | Verifizierbar | Klasse |
|---|---|---|---|---|---|---|
| F-1 | HIGH | Gate-Index und Makefile-Kommentar sagen im Indikativ, `make image-test-ref` sei der Weg, auf dem die Release-Pipeline den einmal gebauten Digest je Plattform testet. Auf diesem Stand ruft `.github/workflows/release.yml` nur `make ci` (Bau + Test des lokalen `:dev`-Bilds); weder `image-test-ref` noch ein Digest-Test kommen dort vor — die Verdrahtung ist Gegenstand von slice-218. Adversarisch geprüft: `grep image-test-ref\|IMAGE_REF` in `.github/` ohne Treffer. | nachweislich falsche Tatsachenbehauptung (Skill HIGH); ADR-0043 Punkt 5 | `harness/README.md:92`; `Makefile:227-228` | ja — `grep -rn image-test-ref .github/` | Künftiger Zustand im Indikativ als bestehender behauptet |
| F-2 | MEDIUM | `multiarch-check.sh` schneidet die Manifest-Liste am **ersten** `]` ab. Trägt ein Eintrag ein Array (`urls`, `platform.os.features`), fallen alle folgenden Einträge aus der Prüfung — gemessen: ein Index mit `linux/amd64`, `linux/arm64` und `linux/s390x` meldet „ok — mit genau: linux/amd64 linux/arm64". Die Schlussprüfung (Zeile 87) zählt dieselbe abgeschnittene Liste und ist damit keine unabhängige zweite Zählung. Kopfkommentar (1) sagt „keine weitere Plattform", Zeile 11-13 „fail-closed"; die tragenden Annahmen (kein Array in einem Eintrag, `mediaType` als erstes Feld) stehen nicht im Kommentar, genannt ist nur „kompakt", das `blob()` ohnehin herstellt. BuildKit erzeugt für `linux/*` heute kein solches Feld — der Pfad ist erreichbar, aber nicht vom aktuellen Erzeuger. | SPEC-DIST-001 („nur diese zwei Plattform-Bilder"); Mess-Regel „Testkommentar sagt nicht mehr zu, als seine Assertion prüft" | `tools/multiarch-check.sh:4-5`, `:11-13`, `:44`, `:86-87` | ja — Mutations-Probe oben (Array-Feld + dritter Eintrag) | Prüfer-Zusage weiter als seine Prüfung |
| F-3 | MEDIUM | §4 des Slice-Plans benennt vorab als Rückführung `in-progress → next`: „das Make-Target braucht eine neue Werkzeugkette im Repo (Builder-Instanz, Emulation) — dann teilen". Geliefert ist ein eigener `docker-container`-Builder mit eigenem, digest-gepinntem BuildKit-Image (`BUILDKIT_IMAGE`, `buildx create`) — eine Builder-Instanz. Weder der Plan noch die Commit-Message sagen, ob die Bedingung als eingetreten gilt oder warum nicht (die Klammer lässt offen, ob *eines* der beiden genügt). Eine Plan-Änderung vor dem Code (`AGENTS.md` §6 Schritt 4) liegt in der Range nicht vor. | slice-217 §4; `AGENTS.md` §6 Schritt 4 | `docs/plan/planning/in-progress/slice-217-multi-arch-build.md:67-68`; `tools/image-multiarch.sh:7-11`, `:28-31`; `Makefile:25` | nein — Urteil über die Lesart der Bedingung | Vorab benannte Rückführungs-Bedingung eingetreten, nicht behandelt |
| F-4 | MEDIUM | ADR-0043 §Fitness Function bindet „Image-Test gegen eine übergebene Bild-Referenz, je Plattform nativ" an `make image-test`. Geliefert ist ein **neues** Target `make image-test-ref`; `make image-test` bleibt an `build` und `${IMAGE}:dev` gebunden. Die Abweichung vom Anker der `Accepted`-ADR ist weder im Slice-Plan noch in der Commit-Message benannt (Review slice-216 F-4 hatte genau diese Zeile adressiert). | ADR-0043 §Fitness Function; `v6.13.0` · `regelwerk/modul-08-agentenrollen.md` §Rollen-Regeln („nicht stillschweigend einer ADR widersprechen") | `docs/plan/adr/0043-multi-arch-ein-bau-getestet-dann-getaggt.md:117`; `Makefile:223`, `:229` | ja — Fitness-Tabelle gegen `make help` | Fitness-Function-Anker und geliefertes Target weichen unbenannt ab |
| F-5 | MEDIUM | Die neue Gate-Index-Zeile `make image-multiarch` überschreitet die Zellengrenze der Vertrags-Spalte (279 Zeichen, Grenze 250); `make doc-structure` — Teil von `make verify`, nicht von `make gates` — ist auf diesem Stand rot: „section-cell-oversized … was darueber hinausgeht, gehoert nach harness/sensors/<target>.md". Die Übergabe meldet `make gates` und `make ci` grün, `make verify` nicht. | Konvention Gate-Index (Zellengrenze, `.d-check.yml` Modul `structure`) | `harness/README.md:93` | ja — `make doc-structure` (Exit 2, ein Befund) | Gate-Index-Zelle über der Zellengrenze |
| F-6 | LOW | `tools/image-test.sh` liest `IMAGE_REF` aus der Umgebung auch unter `make image-test`. GNU make exportiert Kommandozeilen-Variablen in die Rezept-Umgebung (gemessen mit einem Mini-Makefile: `make x IMAGE_REF=foo` → `env=foo`). `make image-test IMAGE_REF=x` bzw. `make ci IMAGE_REF=x` oder ein exportiertes `IMAGE_REF` baut `:dev` und testet dann `x`; der Gate-Index sagt für `image-test` „gegen das gebaute Image". Die Ausgabe nennt das geprüfte Bild (Zeile 47), die Zeile „OK" nicht. | Gate-Index `make image-test`; ADR-0043 („getestet = veröffentlicht") | `tools/image-test.sh:26`; `Makefile:223-224` | ja — `make image-test IMAGE_REF=<anderes Bild>` und die Bild-Zeile der Ausgabe lesen | Umgebungsvariable koppelt zwei Targets still |
| F-7 | LOW | §3 des Slice-Plans nennt vier Dateien; geliefert sind zusätzlich `tools/image-multiarch.sh`, `tools/multiarch-check.sh`, die Guard-Liste und `.gitignore`. Die Guard-Zeile ist Folge des Selbsttests, die zwei Skripte sind eigene Liefer-Substanz (131 Zeilen), die der Plan-Tisch nicht führt. | slice-217 §3 | `docs/plan/planning/in-progress/slice-217-multi-arch-build.md:55-59` | ja — `git show --stat c5533df` gegen §3 | Plan-Tabelle führt die gelieferten Träger unvollständig |
| F-8 | LOW | Der Kopf von `tools/image-test.sh` sagt weiter „gegen das lokal gebaute Runtime-Image"; seit diesem Diff prüft das Skript wahlweise ein übergebenes Bild (Zeile 22-23 sagt es richtig). Der Kopfsatz beschreibt nicht mehr vollständig, was da ist. | `AGENTS.md` §3.7 | `tools/image-test.sh:2-3` | nein — Lesart | Kopfkommentar nach Erweiterung nicht nachgezogen |
| F-9 | INFO | Die Fehlerpfade „Layer nicht gzip" und „Binary nicht im letzten Layer" enden rot mit Exit 2 und der Meldung von `tar`, nicht mit einem `multiarch-check: FAIL`. Fail-closed, aber die Diagnose nennt die verletzte Annahme nicht. | — | `tools/multiarch-check.sh:70-75` | ja — Probe oben | — (Hinweis) |
| F-10 | INFO | Der Pin `BUILDKIT_IMAGE` trägt Tag **und** Digest; `make version-coherence` prüft nur `uses:`-SHAs und Makefile/Dockerfile-Doppel, nicht dieses Paar. Heute stimmt es (nachgemessen). Klasse von `BEO-GATE/versionsangabe-neben-digest-ungeprueft`; Adressat ist die Closure. Ebenso bleibt der Builder-Container nach dem Lauf stehen — kein Aufräumen, keine Aussage dazu. | AC-QA-03 | `Makefile:25`; `tools/image-multiarch.sh:28-31` | ja — `docker buildx imagetools inspect` des Tags | — (Hinweis) |
| F-11 | INFO | ADR-0043 Punkt 5 und SPEC-DIST-001 verlangen den Image-Test „einschließlich des Versions-Labels"; `tools/image-test.sh` prüft das Label nicht. slice-218 §2 führt „Versions-Label je Plattform" in `release.yml` — ob der Träger der Image-Test oder ein Pipeline-Schritt wird, entscheidet dort der Implementer. | ADR-0043 Punkt 5 | `tools/image-test.sh` | nein | — (Hinweis an slice-218) |

## Negativbefunde

| Bereich | Ergebnis |
|---|---|
| Dockerfile — Wirkung von `--platform=$BUILDPLATFORM` auf `compile`/`lint`/`test`/`coverage` | geprüft: bei einplattformigem `docker build` ist `BUILDPLATFORM` = `TARGETPLATFORM`; `lint` kopiert nur den plattformneutralen Modul-Cache aus `deps`; `# syntax=docker/dockerfile:1.7` setzt BuildKit ohnehin voraus. `make gates` Exit 0. Ohne Befund |
| Dockerfile — Laufzeit-Stufe ohne `RUN`, `GOOS`/`GOARCH` aus `TARGETOS`/`TARGETARCH` (ADR-0043 Punkt 2) | geprüft; Gegenprobe ohne `GOOS`/`GOARCH` rot mit ELF-Meldung. Ohne Befund |
| `--provenance=false --sbom=false` (ADR-0043 Punkt 3) | geprüft; Attestierungs-Probe rot. Ohne Befund |
| `multiarch-check.sh` — Config-Architektur, Versions-Label, ELF je Plattform, Dubletten, Fehlzeiger | geprüft per Mutation (Tabelle oben), jeweils rot aus dem richtigen Grund; Befund nur F-2 |
| `image-test.sh` — Zusage „Plattform des Hosts geprüft" | geprüft: ELF-Prüfung vor dem Nativ-Lauf, rot gegen das arm64-Manifest auf `x86_64`, grün gegen den Index (Docker zieht die Host-Plattform). Ohne Befund |
| Guard-Liste und `make guard-selftest` | geprüft; Mutation (Liste ohne die zwei Targets) rot mit Namen. Ohne Befund |
| Gate-Index — beide Zeilen existieren als Regel (`make doc-targets` Exit 0), Bindung ADR-0043/slice-217, „Nicht hier"-Absatz nachgezogen | geprüft; Befunde F-1 (Wahrheit der Release-Pipeline-Aussage) und F-5 (Zellengrenze) |
| §1 Ausschlüsse — Release-Pipeline, Push, Spiegel, Gate-Stages für arm64 | geprüft: `release.yml`, `packaging/`, Gate-Stages im Diff unberührt. Ohne Befund |
| Kommentare `AGENTS.md` §3.7 — Dockerfile, Makefile, beide neuen Skripte | geprüft: die Konjunktive (`od -N2` am Pipe-Ende, `head -1`) zeigen nach vorn auf einen Fallstrick für den Ändernden (Klasse Abgrenzung), nicht zurück auf eine verworfene Alternative. Befund nur F-8 |
| Hard Rules §3.1–§3.6 (Docker/make-only, keine Suppression, kein Move, keine ADR überschrieben, kein Gate gelockert) | geprüft, ohne Befund |
| `BUILDKIT_IMAGE` digest-gepinnt (AC-QA-03), Pin = Index-Digest des Tags | nachgemessen, ohne Befund |

## Summary

| Kategorie | Anzahl |
|---|---|
| HIGH | 1 |
| MEDIUM | 4 |
| LOW | 3 |
| INFO | 3 |

**Finding-Klassen dieses Laufs:** Künftiger Zustand im Indikativ als bestehender behauptet ·
Prüfer-Zusage weiter als seine Prüfung · Vorab benannte Rückführungs-Bedingung eingetreten, nicht
behandelt · Fitness-Function-Anker und geliefertes Target weichen unbenannt ab · Gate-Index-Zelle über der Zellengrenze · Umgebungsvariable
koppelt zwei Targets still · Plan-Tabelle führt die gelieferten Träger unvollständig ·
Kopfkommentar nach Erweiterung nicht nachgezogen

## Verdikt

**Abnahme-blockierend:** ja — F-1 (HIGH) und F-2 bis F-5 (MEDIUM) sind vor der Closure zu klären.
F-3 ist eine Plan-Frage (Lesart der Rückführungs-Bedingung) und geht an den Planner; F-4 betrifft
den Anker einer `Accepted`-ADR — widerspricht der Implementer, läuft der Konflikt-Pfad über den
Architect. Die übrigen Behauptungen der Übergabe (Gegenproben) sind nachgefahren und bestätigt.

**Übergabe:** Findings an den Implementer; die Finding-Klassen zusätzlich in die Closure §7 von
slice-217. Dieser Report ist Lauf-Beleg und ersetzt keine Verifikation gegen die DoD.

---

## Delta-Review

**Gegenstand:** `3962a6d..5131de5` — die Range beginnt beim Elternteil von `3962a6d`, umfasst
also beide Commits: `3962a6d` (Plan-Änderung: Bewertung von F-3, Weg für F-4/F-6, Plan-Tabelle
F-7), `5131de5` (Fixes). Derselbe Reviewer-Kontext wie oben, gleicher Skill-Stand.

**Eigene Nachmessung** (Geltungsbereich wie oben: Host `x86_64`, BuildKit-Archiv aus
`make image-multiarch`, handgebaute Mutationen, eigene Registry auf Port 5187, danach entfernt):

| Probe | Ergebnis (Meldung) |
|---|---|
| `make image-multiarch VERSION=9.9.9-rev` | Exit 0 |
| nur amd64 · amd64 doppelt · Attestierung · `urls`-Array + s390x · `os.features` + s390x · `subject`-Feld im Index | rot — „der Index führt n Digest(s) und n Manifest-Medientyp(en) — erwartet genau 2 und 2" |
| arm64-Eintrag zeigt auf das amd64-Manifest | rot — „Plattformen 'linux/amd64 linux/amd64'" |
| Layer unkomprimiert · Binary nicht im letzten Layer | rot — „linux/arm64: der letzte Layer ist kein gzip-tar mit /a-check" |
| arm64-Manifest mit amd64-Binary-Layer | rot — „ELF e_machine '62', erwartet '183'" |
| Feldreihenfolge `digest` vor `mediaType` · eingerückter Index | grün — korrekt |
| **Plattform-Felder der zwei Index-Einträge vertauscht** | **grün** (D-1) |
| **Index-Einträge mit `linux/s390x` und `windows/386` beschriftet**, Manifeste unverändert | **grün** (D-1) |
| `make -n image-test IMAGE_REF=foo` / ohne `IMAGE_REF` | ohne bzw. mit `docker build` |
| `make image-test IMAGE_REF=<Index-Digest>` | Exit 0, kein Bau |
| `make image-test IMAGE_REF=<arm64-Manifest-Digest>` | rot — „ELF e_machine 183, Host x86_64 erwartet 62" |
| `make guard-selftest`, `make doc-targets`, `make doc-structure`, `make doc-check` | Exit 0 (Ausgabe in Datei, Exit-Code getrennt) |

### Status der Findings

| ID | Status | Beleg |
|---|---|---|
| F-1 | behoben — Pipeline-Satz aus Gate-Index und Makefile entfernt; `image-test-ref` entfällt | `harness/README.md` Zeile `make image-test`; `Makefile` vor `image-test:` |
| F-2 | behoben für die gemeldete Klasse — Array-Feld + dritter Eintrag jetzt rot, zwei verschieden gebaute Zähler; der Umbau öffnet aber D-1 | Probe oben |
| F-3 | beantwortet — Bewertung in §4 vor dem Fix (`3962a6d`): eingetreten ist die Builder-Instanz, nicht die Emulation; nicht geteilt mit Begründung. Ob die Begründung trägt, ist ein Planner-Urteil; als Review-Befund ohne weitere Aktion | slice-217 §4 |
| F-4 | behoben — `make image-test IMAGE_REF=…` ohne Bau; Fitness Function von ADR-0043 stimmt mit dem Target überein | Probe oben; Plan-Änderung `3962a6d` liegt vor `5131de5` |
| F-5 | behoben — `make doc-structure` Exit 0 | Probe oben |
| F-6 | behoben — `IMAGE_REF` wirkt jetzt bestimmungsgemäß, auch unter `make ci`; der Makefile-Kommentar sagt es | `Makefile` vor `image-test:` |
| F-7 | behoben — Plan-Tabelle führt Skripte, Guard, `.gitignore` | slice-217 §3 |
| F-8 | behoben — Skript-Kopf nennt beide Bild-Quellen | `tools/image-test.sh:2-4` |
| F-9 | behoben — tar-Fehler mit eigener Meldung | Probe oben |
| F-10, F-11 | offen, vom Implementer in Closure bzw. slice-218 übernommen | — |

### Neue Findings

| ID | Kategorie | Befund | Quelle | Pfad | Verifizierbar | Klasse |
|---|---|---|---|---|---|---|
| D-1 | MEDIUM | Der Prüfer liest die `platform`-Felder des Index nicht mehr; die Plattform eines Eintrags kommt nur aus seiner Config. Ein Index, dessen Einträge vertauscht oder als `linux/s390x`/`windows/386` beschriftet sind, meldet „ok — mit genau: linux/amd64 linux/arm64" (gemessen). Docker wählt beim Ziehen nach genau diesen Feldern — ein amd64-Rechner bekäme im ersten Fall das arm64-Bild, im zweiten keines. Der Kopfkommentar (1) sagt „der Index führt GENAU zwei Einträge: linux/amd64 und linux/arm64"; geprüft ist die Zahl der Einträge und die Plattform der Configs, nicht die Beschriftung im Index. Die erste Fassung hatte diese Prüfung („Config sagt …"); der Umbau für F-2 hat sie entfernt. BuildKit erzeugt eine solche Beschriftung nicht — der Pfad ist erreichbar, aber nicht vom aktuellen Erzeuger. | SPEC-DIST-001 (Pin löst auf beiden Plattformen auf); Mess-Regel „Testkommentar sagt nicht mehr zu, als seine Assertion prüft" | `tools/multiarch-check.sh:4-6`, `:16`, `:59-70` | ja — Mutations-Probe (Plattform-Felder vertauschen) | Prüfer-Zusage weiter als seine Prüfung |

### Negativbefunde (Delta)

| Bereich | Ergebnis |
|---|---|
| `Makefile` — `image-test: $(if $(IMAGE_REF),,build)`, Rezept reicht `IMAGE_REF` durch; Kommentar Indikativ über den Zustand | geprüft, ohne Befund |
| Guard-Liste, `.PHONY`, Gate-Index und „Nicht hier"-Absatz nach Wegfall von `image-test-ref` | geprüft; `make guard-selftest`, `make doc-targets` Exit 0; ohne Befund |
| `multiarch-check.sh` — Zähler über `"digest"`-Schlüssel und Manifest-Medientypen, `subject`-Feld, Annotationen | geprüft per Mutation; Befund nur D-1 |
| Kommentare `AGENTS.md` §3.7 im Delta (Kopf von `multiarch-check.sh`, `image-test.sh`, Makefile) | geprüft; der Satz „ein Array-Feld … schnitte sie falsch" zeigt als Abgrenzung auf einen Fallstrick für den Ändernden; ohne Befund außer D-1 (Zusage-Umfang) |
| Plan-Änderung vor dem Fix (`AGENTS.md` §6 Schritt 4) | geprüft: `3962a6d` liegt vor `5131de5`; ohne Befund |
| `release.yml` im Delta | unberührt; ohne Befund |
| Hard Rules §3.1–§3.6 im Delta | geprüft, ohne Befund |

### Summary (Delta)

| Kategorie | Anzahl |
|---|---|
| HIGH | 0 |
| MEDIUM | 1 |
| LOW | 0 |
| INFO | 0 |

F-1 bis F-9 sind behoben oder beantwortet, F-10/F-11 übergeben. Neue Finding-Klasse: keine — D-1
trägt dieselbe Klasse wie F-2 (*Prüfer-Zusage weiter als seine Prüfung*), im selben Prüfer zum
zweiten Mal in diesem Slice. Gezählt wird das bei der Closure, nicht hier.

### Verdikt (Delta)

**Abnahme-blockierend:** ja, wegen D-1 (MEDIUM) — vor der Closure zu klären. Sonst ist die
Übergabe nachgefahren und bestätigt.

### Delta-Review 2

**Gegenstand:** `9c70771` — Fix für D-1 in `tools/multiarch-check.sh`: je Digest wird die
`platform`-Beschriftung des Index-Eintrags (Abschnitt zwischen diesem und dem nächsten
`"digest"`-Schlüssel) gegen os/architecture der Config gehalten. Nur D-1 geprüft; derselbe
Reviewer-Kontext, gleicher Skill-Stand.

**Eigene Nachmessung** (Geltungsbereich wie oben; Archiv neu aus `make image-multiarch`,
Mutationen handgebaut):

| Probe | Ergebnis (Meldung) |
|---|---|
| Kontrolle `make image-multiarch VERSION=9.9.9-rev` | Exit 0 |
| Plattform-Felder vertauscht | rot — „der Index beschriftet sha256:bd01… als 'linux/arm64', die Config sagt …" |
| Beschriftung `linux/s390x` / `windows/386` | rot — „… als 'linux/s390x' …" |
| `platform` **vor** `digest` in beiden Einträgen (unvertauscht) | rot — falsche Beschriftung gefunden; deckt den Kommentar „andere Reihenfolge … ist rot" |
| dasselbe, vertauscht | rot — Beschriftung `'/'` |
| arm64-Eintrag ohne `platform` | rot — Beschriftung `'/'` |
| Feldreihenfolge `digest` vor `mediaType` · eingerückt · `variant: v8` | grün — korrekt |
| alle früheren Fälle (nur amd64, Dublette, Attestierung, Fehlzeiger, Array + s390x, `subject`, Layer-Fehler, Binary vertauscht, falsche Version) | rot wie im Delta-Review |
| arm64-Eintrag ohne `platform`, dafür ein **nicht-schematisches** Feld `"platform":{…arm64…}` auf der obersten Ebene des Index **nach** `manifests` | grün (D2-1) |

### D-1

**Bestätigt behoben.** Die Beschriftung im Index wird gelesen und gegen die Config gehalten; die
beiden Fälle aus D-1 sind rot aus dem genannten Grund, und die Schlüssel-Reihenfolge, die der
Kommentar als rot zusagt, ist rot.

### Neue Findings

| ID | Kategorie | Befund | Quelle | Pfad | Verifizierbar | Klasse |
|---|---|---|---|---|---|---|
| D2-1 | INFO | Für den **letzten** Eintrag reicht der gesuchte Abschnitt bis zum Ende des Index. Fehlt dort die eigene `platform`, greift ein `"platform":{…}` außerhalb der Manifest-Liste (gemessen mit einem Feld auf oberster Ebene). Das OCI-Schema kennt dort kein solches Feld, und BuildKit schreibt keines; der Fall ist konstruiert und hier nur benannt. | SPEC-DIST-001 | `tools/multiarch-check.sh` (Abschnitt `seg`) | ja — Mutations-Probe oben | — (Hinweis) |

### Summary (Delta 2)

| Kategorie | Anzahl |
|---|---|
| HIGH | 0 |
| MEDIUM | 0 |
| LOW | 0 |
| INFO | 1 |

### Verdikt (Delta 2)

**Abnahme-blockierend:** nein. D-1 ist behoben; offen bleiben F-10/F-11 (übergeben) und der Hinweis
D2-1. Dieser Report ist Lauf-Beleg und ersetzt keine Verifikation gegen die DoD.
