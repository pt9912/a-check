# slice-191 — Phrasen-Sensor gegen Chronik in lebenden Dateien

**Welle:** ohne Welle.

**Bezug:** Ausgang von
[`BEO-HARNESS/chronik-in-gelesenen-dateien`](../observations/BEO-HARNESS/chronik-in-gelesenen-dateien/observation.md)
bei **3×** (*geplant*); ausgelöst durch
[slice-187](../done/wellenlos/slice-187-voll-abgleich-erstdurchgang-rest.md) §3.6.
[`AC-QA-02`](../../../../spec/lastenheft.md#ac-qa-02--hermetik-und-ehrliche-heuristik-grenze).

**Berührte Spec-Stellen:** — · Der Slice berührt kein Spec-Stratum.

**Verantwortlich:** Claude — gesetzt beim Übergang nach `in-progress/`.

**Autor:** Claude. **Datum:** 2026-09-08.

**Lerneintrag — Form:** wird bei Closure benannt.

---

## 1. Ziel und Abgrenzung

**Ziel:** Die **häufige Schreibweise** von Chronik in lebenden Dateien ist
maschinell gefangen — ein `forbid-pattern` im Modul `structure`, konfiguriert in
[`.d-check.yml`](../../../../.d-check.yml), im `gates`-Aggregat. Gegenstand sind
die Dateien, die **jeder Lauf liest**: `AGENTS.md`, `harness/*.md`,
`docs/plan/planning/README.md`.

**Die Grenze gehört in denselben Slice wie der Sensor.** Er prüft eine
**Phrase**, nicht die Klasse *Chronik*; ob ein Satz Chronik ist, bleibt ein
Urteil ([`AGENTS.md`](../../../../AGENTS.md) §3.7). Die Sensor-Datei unter
[`harness/sensors/`](../../../../harness/sensors/) sagt das, bevor jemand ihn
für den ganzen Wächter hält — dieselbe Falle wie bei
[`BEO-GATE/muster-trifft-nur-die-haeufige-schreibweise`](../observations/BEO-GATE/muster-trifft-nur-die-haeufige-schreibweise/observation.md).

**Ausdrücklich NICHT in diesem Slice** — je Punkt mit Begründung:

- **Zeitdokumente** (`docs/plan/planning/**`, `docs/reviews/**`,
  `docs/plan/adr/**`). *Schicht-Abgrenzung:* Dort ist Chronik **richtig** — ein
  Slice-Plan, ein Review-Report und eine ADR sind Belege eines Vorgangs. Ein
  Muster, das dort feuert, wäre abgeschaltet, bevor es zweimal gelaufen ist.
- **Eine Erweiterung auf sinngemäße Chronik.** *Es wäre ein anderer Vorgang:*
  Das ist die Klasse, nicht ihre Schreibweise, und für sie gibt es keinen
  Sensor.
- **Rückbau von Chronik im Bestand.** *Bestand bleibt bewusst stehen:* Die
  bekannten Stellen sind mit slice-103, slice-182 und slice-187 behoben; was der
  neue Lauf zusätzlich findet, ist Gegenstand **dieses** Slice — was er nicht
  findet, ist keine Aufgabe, die er erzeugt.

## 2. Ausgangsmessung

*(beim Übergang nach `in-progress/` zu erheben. Erwartung aus slice-187:
`grep -n "Bis slice-" AGENTS.md` liefert **null** Treffer — der Bestand ist
sauber, und ein Sensor, der auf null Treffern eingeschaltet wird, braucht eine
**Mutations-Probe**, sonst ist er grün ohne Gegenstand.)*

## 3. Umsetzung

| Datei / Komponente | Änderungs-Art | Begründung |
|---|---|---|
| [`.d-check.yml`](../../../../.d-check.yml) (structure, Bedingung 8) | neu | drei Chronik-Phrasen als `forbid-pattern` auf `AGENTS.md`, `harness/*.md`, Planning-README |
| `tools/dcheck-phrase-selftest.sh` (Muster 4) | neu | Positiv/Negativ/Zitat/Scoping-Kontrollen gegen eigene Fixtures |
| [`harness/sensors/dcheck-phrase-selftest.md`](../../../../harness/sensors/dcheck-phrase-selftest.md), [`harness/README.md`](../../../../harness/README.md) | update | Zählung und Muster-4-Grenze dokumentiert |

*(entsteht mit der Arbeit)*

## 4. Definition of Done

- [x] Das Muster ist in [`.d-check.yml`](../../../../.d-check.yml) konfiguriert
      und hängt im `verify`-Aggregat (structure läuft dort, nicht in `gates` —
      gemessen, siehe Closure „Was ging anders").
- [x] Die **Mutations-Probe** ist gefahren und war **rot**, mit genannter
      Meldung (`section-forbidden`): eine eingefügte Chronik-Zeile in einer
      lebenden Datei wird gemeldet, dieselbe Zeile in einem Slice-Plan **nicht**
      (Scoping-Kontrolle im Selbsttest, Muster 4).
- [x] Die Sensor-Doku ([`harness/sensors/dcheck-phrase-selftest.md`](../../../../harness/sensors/dcheck-phrase-selftest.md))
      nennt die Grenze: Phrase statt Klasse, und welche Umformulierung entkommt.
- [x] Unabhängiger Review durchgeführt (Report unter [`docs/reviews/`](../../../reviews/README.md)).
- [x] Closure-Notiz mit Steering-Loop-Lerneintrag.
- [x] Beobachtungs-Register fortgeschrieben.
- [x] Jedes Risiko aus §7 trägt einen Ausgang.

`make gates` und `make verify` grün.

## 5. Trigger

**Start** (`open` → `in-progress`): das WIP-Limit ist frei. Keine Abhängigkeit
von slice-188/189/190.

**Rückführungen — vorab benannt:**

- `in-progress` → `next` (zu groß): Zeigt die Probe, dass das Muster im Bestand
  massenhaft feuert, ist der Rückbau ein eigener Slice und das Muster wartet auf
  ihn — ein Gate, das den Bestand bricht, wird abgeschaltet statt befolgt.
- `in-progress` → `open` (blockiert): Kann `structure` kein `forbid-pattern` auf
  eine ganze Datei (statt auf eine Sektion) legen, ist es ein CR an `d-check`
  und keine Konfiguration.

## 6. Closure-Trigger

DoD vollständig, `make gates` und `make verify` grün, Closure-Notiz mit
Lerneintrag.

## 7. Risiken und offene Punkte

- **Ein Phrasen-Sensor kann für den Wächter der Regel gehalten werden.** Genau
  das ist die Klasse, die er nur zur Hälfte fängt — und die Verwechslung ist im
  Repo belegt. — **Ausgang:** *entfallen*, gestrichen mit Begründung: die Grenze
  steht am Sensor selbst (GRENZE-Kommentar der Bedingung 8 und Sensor-Doku
  dcheck-phrase-selftest.md, Muster 4) — der Sensor prüft eine Phrase, nicht
  die Klasse, und die Beobachtung sagt genau das.
- **Das Muster kann in Zitaten feuern.** Ein Slice-Plan, der die Regel
  *erklärt*, zitiert die verbotene Wendung; liegt er im Geltungsbereich, meldet
  der Lauf gegen einen legitimen Satz. — **Ausgang:** *entfallen*, gestrichen
  mit Begründung: die ZITAT-Kontrolle (Muster 4) bleibt grün — Inline-Code-
  Nennungen werden nicht getroffen (gemessen gegen den gepinnten Digest).
- **Der Bestand ist sauber, die Prüfmenge also leer.** Ein Prüfer mit leerer
  Prüfmenge meldet grün und ist damit nicht „unbenutzt", sondern unkalibriert —
  deshalb die Mutations-Probe in der DoD.
  — **Ausgang:** *entfallen*, gestrichen mit Begründung: die Positiv-Kontrolle
  (Muster 4) belegt, dass das Muster feuert; der Bestand ist sauber (0 Befunde
  über 609 Dateien) — die Korpus-Leere ist der Normalfall des behobenen
  Bestands, der stille Null-Lauf ist durch die Mutations-Probe verhindert.

## 8. Closure-Notiz

**Lerneintrag — Form: neuer Sensor.** *Die Grenze gehört an den Sensor, nicht
in die Fußnote.* Die Beobachtung selbst forderte es („die Grenze gehört an den
Sensor, nicht in die Fußnote"), und die Bedingung 8 trägt sie am Ort der
Wirkung: `forbid-pattern` auf die drei Chronik-Phrasen in den gelesenen
Dateien, mit GRENZE-Kommentar (Phrase statt Klasse, Umformulierung entkommt).
liegt in `.d-check.yml` (structure, Bedingung 8) plus
`tools/dcheck-phrase-selftest.sh` (Muster 4, vier Kontrollen).
Auslöser: `BEO-HARNESS/chronik-in-gelesenen-dateien`
(slice-103, slice-182, slice-187 — 3×).

**Was hat funktioniert:** die Sollform war im Beobachtungs-Eintrag vollständig
vorbereitet (drei Phrasen, Ziel-Dateien, Grenze) — der Sensor war die
Umsetzung eines abgestimmten Entscheids, keine Neuentdeckung.

**Was ging anders als geplant:** der DoD-Punkt „hängt im `gates`-Aggregat"
war ein Überbleibsel — `structure` läuft im `verify`-Aggregat (gemessen, wie
schon slice-202 F-3). Die Scoping-Kontrolle (Chronik in einem Slice-Plan)
wurde erst falsch gebaut (die Fixture bekam die Slice-Plan-Regel, die es so
nicht gibt) und dann auf den echten Geltungsbereich zurückgebaut.

**Steering-Loop-Eintrag:** Sensor neu: Chronik-Phrasen in gelesenen Dateien
— liegt in `.d-check.yml` (structure, Bedingung 8) plus
`tools/dcheck-phrase-selftest.sh` (Muster 4). Auslöser:
`BEO-HARNESS/chronik-in-gelesenen-dateien`
(slice-103, slice-182, slice-187 — 3×).

**Beobachtungs-Register (`../observations/`):**
`BEO-HARNESS/chronik-in-gelesenen-dateien/` — Ausgang *verkörpert*
(`seit slice-191`, Sensor Bedingung 8).

**Folge-Slices:** — *(keine.)*

**Risiken aus §6:** jedes mit genau einem Ausgang — siehe §6.

**Drei Paarungen:** Anker — der Steering-Loop-Eintrag liegt in `.d-check.yml`
(Bedingung 8) mit `seit slice-191` · Folge-Slice — keine · Register —
chronik-in-gelesenen-dateien ist verkörpert, der Stand trägt den Anker.

## 9. Sub-Area-Prüfungen und Modus-Begründung

**Vorgelagert — Sub-Area-Wahl prüfen:** *(beim Übergang nach `in-progress/`
auszufüllen — berührt sind `GATE` (die Konfiguration) und `HARNESS` (die
geprüften Dateien).)*

**Vorgelagert — offene Beobachtungen sichten:** *(ebenso — **zwei** Quellen:
Register und der Review-Report des Vorgänger-Slice; das Register ist **nach
allen berührten Kürzeln** zu lesen, siehe slice-187 §3.6.)*
