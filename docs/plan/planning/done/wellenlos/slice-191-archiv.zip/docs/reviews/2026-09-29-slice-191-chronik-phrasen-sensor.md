# Review-Report: slice-191 — 2026-09-29

**Review-Art:** Code — geprüft gegen den Slice-Plan, die Beobachtung
`BEO-HARNESS/chronik-in-gelesenen-dateien` und die Hard Rules
(`AGENTS.md` §3, §5) sowie die Mess-Regeln des Skills.

**Gegenstand:** `slice-191` — Range `HEAD~4..HEAD`
(`72bf56d` Archivierung slice-201 · `665d7fc` git mv · `ecfa2b4`
Sensor-Verdrahtung · `81a110e` Closure).

**Skill:** `.harness/skills/reviewer.md` @ `81a110e`
**Modell:** GLM (glm-5.3-flash) · **Datum:** 2026-09-29

**Eingangs-Kontext:** Slice-Plan `slice-191` ·
`BEO-HARNESS/chronik-in-gelesenen-dateien` (`observation.md`,
`state.md`@`ecfa2b4` inkl. Sollform, drei Evidence-Dateien) ·
`AGENTS.md` §3.7, §5 · `.d-check.yml` (structure, Bedingung 8) ·
`tools/dcheck-phrase-selftest.sh` · `harness/README.md` ·
`harness/sensors/dcheck-phrase-selftest.md` · `Makefile`/`d-check.mk`
(Aggregat-Zugehörigkeit, Pin `sha256:b4b8756b…`).

---

## Findings

| ID | Kategorie | Befund | Quelle | Pfad | Verifizierbar | Klasse |
|---|---|---|---|---|---|---|
| F-1 | HIGH | Der Closure-Commit attestiert „Unabhängiger Review durchgeführt (Report unter `docs/reviews/`)" — ein Report zu slice-191 existiert zu diesem Zeitpunkt nicht; er entsteht erst mit diesem Lauf. Ein abgehaktes DoD-[x] bezeugt einen Vorgang, der noch aussteht; es ist die vierte Auflage der Klasse (slice-169, slice-197, slice-200). | `BEO-GATE/attestierung-vor-dem-vorgang` (3×) | docs/plan/planning/in-progress/slice-191-chronik-phrasen-sensor.md:72 | ja — `make doc-reviews` wird nach dem `git mv` nach `done/` rot, solange kein Report existiert | Attestierung vor dem Vorgang |
| F-2 | HIGH | Die Zitat-Kontrolle des Musters 4 ist hohl: `setup_chronik_fixture` interpoliert `${body}` als String, der Aufruf übergibt `$TMP/body-chronik-zitat.txt` — die Fixture trägt den Pfad-String, nie die Phrase, und kann nicht rot gehen. Gemessen: Mutante mit ausgeliefertem Body → rot („das Chronik-Muster trifft die zitierte Phrase"), denn d-check entwaffnet Inline-Code, nicht doppelte Anführungszeichen; der Fixture-Text behauptet „sind in Inline-Code zitiert", steht aber in Anführungszeichen. Der Risiko-Ausgang §7 zitiert dieselbe Kontrolle als „gemessen gegen den gepinnten Digest". | `AGENTS.md` §5 (Mutations-Probe belegt erst, wenn sie rot war); `BEO-GATE/probe-liefert-den-gegenstand-mit` (3×) | tools/dcheck-phrase-selftest.sh:299 (Aufruf), 256–276 (Fixture), 295–298 (Body) | ja — Mutante (Body-Inhalt statt Pfad) macht den Lauf rot; Protokoll unten | Probe liefert den Gegenstand mit |
| F-3 | HIGH | DoD-Punkt 3 und der Risiko-Ausgang §7 behaupten, die Sensor-Doku nenne die Grenze „Phrase statt Klasse, und welche Umformulierung entkommt" — die Datei nennt sie nicht: „Chronik" kommt in ihr nicht vor, ihr Grenze-Abschnitt trägt nur die drei Alt-Punkte. Der Ausgang „entfallen" stützt sich zur Hälfte auf ein Artefakt, das die Behauptung nicht trägt (der GRENZE-Kommentar in `.d-check.yml` Bedingung 8 trägt sie). | nachweislich falsche Tatsachenbehauptung (Reviewer-Skill); `AGENTS.md` §3.7 | docs/plan/planning/in-progress/slice-191-chronik-phrasen-sensor.md:70–71 (DoD), 102–105 (§7) | ja — `grep -c Chronik harness/sensors/dcheck-phrase-selftest.md` = 0 | Beleg verweist auf nicht vorhandenen Inhalt |
| F-4 | HIGH | Gate-Index und Sensor-Doku nennen **elf** Werkzeug-Kontrollen; der Selbsttest läuft mit **12** (2+2+4+4) und meldet das selbst — eigener Lauf, Exit 0, „12 Werkzeug-Kontrollen (4 Muster)". Ursprung der 11: der Skript-Kommentar zählt „DREI Kontrollen" für Muster 4 und verschweigt die Scoping-Kontrolle; 8 + 3 = 11. Die eigene Zähl-Doppelung (11 in zwei Dokumenten, 12 im Skript) ist der Befund. | `AGENTS.md` §5 (Wer eine Menge zählt, zählt sie zweimal verschieden); nachweislich falsche Tatsachenbehauptung | harness/README.md:81 · harness/sensors/dcheck-phrase-selftest.md:10 · tools/dcheck-phrase-selftest.sh:246 (Kommentar) gegen 394 (Erfolgszeile) | ja — `make dcheck-phrase-selftest`, Erfolgszeile sagt 12 | Zählung divergiert vom Zähllauf |
| F-5 | MEDIUM | Die Scoping-Kontrolle spiegelt den echten Geltungsbereich nicht: ihre Fixture-Konfiguration trägt nur die AGENTS.md-Regel, der Chronik-Slice-Plan liegt damit trivial außerhalb jeder Prüfmenge. Eine später verbreiterte `files:`-Glob im echten Bestand würde die Kontrolle nicht rot machen; der Kommentar „Die Fixture nutzt die echte Konfigurationsform" überschreibt das. Gemessen ist das Verhalten des echten Bestands korrekt (Negativbefund 3) — die Kontrolle pinnt es nur nicht. | `AGENTS.md` §5 (Mutations-Probe belegt erst, wenn sie rot war) | tools/dcheck-phrase-selftest.sh:306–341 | ja — Mutante mit verbreiterter Glob bliebe im Selbsttest grün | Probe liefert den Gegenstand mit |
| F-6 | LOW | Die Sensor-Doku sagt „vier Muster" und enumeriert drei (reviews-Phrase, tasks-ignore-pattern, DoD-Häkchen); das Chronik-Muster fehlt in der Aufzählung, und die Prosa darunter bleibt beim Alt-Stand „zwei Muster" — der Commit aktualisiert die Zählspalte, nicht die Aufzählung und den Absatz. | Maintainability | harness/sensors/dcheck-phrase-selftest.md:10, 13–14 | ja — Lesen | Nachzug fehlt in Aufzählung |
| F-7 | LOW | Der Kommentar der Bedingung 8 trägt ein Chronik-Fragment: „(slice-202… nein: slice-191)" — ein Selbstkorrektur-Einschub, der den Schreibakt erzählt, im Kommentar des Sensors gegen Chronik. slice-202 existiert (keine erfundene ID); der finale Zeiger ist korrekt. | `AGENTS.md` §3.7 | .d-check.yml:448 | nein — inferentiell, kein Gate | Chronik in lebenden Dateien |
| F-8 | LOW | Plan §1 behält die Aussage „im `gates`-Aggregat" bei, während DoD und Closure sie auf `verify` korrigiert haben — der Plan widerspricht sich intern; das Makefile bestätigt `verify` (Zeile 196; die `gates`-Liste führt `doc-structure` nicht). | `AGENTS.md` §3.7 (Zustandsfeld — der Zustand, nicht die Chronik der Korrektur) | docs/plan/planning/in-progress/slice-191-chronik-phrasen-sensor.md:25 | ja — `Makefile` | Dokument-interner Widerspruch |
| F-9 | LOW | §3 Umsetzung bleibt leer („entsteht mit der Arbeit") — die Umsetzungs-Entscheidungen (Muster-Extraktion fail-closed, Scoping-Neubau nach Fehlbau) sind nur über Commits und Closure-Notiz rekonstruierbar, nicht im Plan belegt. | Maintainability | docs/plan/planning/in-progress/slice-191-chronik-phrasen-sensor.md:59 | nein | Plan-Sektion unausgefüllt |
| F-10 | INFO | Das Muster ist case-sensitive: satzanfangs „Bis slice-99 tat das …" und einschzig „… bis slice-99 stand hier …" entkommen (gemessen, Proben 2c/2d). Das liegt innerhalb der deklarierten Grenze (Phrase statt Klasse), ist aber eine ausprägenswerte Fall-Variante — und die Datei, die die Grenze nennen sollte, trägt sie nicht (F-3). | Grenze des Sensors | .d-check.yml:456, 461, 466 | ja — Proben 2c/2d, Protokoll unten | Fallvariante entkommt Muster |

## Messungs-Protokoll (eigene Ausführung, Digest `sha256:b4b8756b…` aus `d-check.mk`)

| Probe | Fixture | Erwartung | Ergebnis |
|---|---|---|---|
| 1 | Chronik-Zeile „Bis slice-99 stand hier…" in AGENTS.md | rot | `section-forbidden` ✓ |
| 2b | belegte Wendung „(bis slice-99 tat das …)" in harness/conventions.md | rot | `section-forbidden` ✓ |
| 3 | dieselbe Zeile im Slice-Plan, Config spiegelt die drei echten Regeln | grün | grün (Exit 0) ✓ |
| 4 | Umformulierung „Vorher hatte man hier …" in AGENTS.md | grün | grün ✓ — Grenze Phrase statt Klasse real, nicht still überwunden |
| 5a | Phrase in Inline-Code (Backticks) | grün | grün ✓ |
| 5b | Phrase in doppelten Anführungszeichen | grün (laut Zitat-Kontrolle) | **`section-forbidden`** — belegt F-2 |
| 5c | Phrase in Code-Block | grün | grün ✓ |
| 7 | Chronik in docs/plan/planning/README.md | rot | `section-forbidden` ✓ |
| 2c/2d | Fall-Varianten der belegten Wendungen | — | grün — belegt F-10 |
| Mutante 1 | Selbsttest, Zitat-Fixture erhält Body-Inhalt | rot | **rot** — „das Chronik-Muster trifft die zitierte Phrase" |
| Mutante 3 | Selbsttest, Zitat-Fixture mit Backtick-Form + Body-Inhalt | grün | grün — die intendierte Kontrolle wäre bestanden worden |
| `make dcheck-phrase-selftest` | — | grün | grün; Erfolgszeile: „12 Werkzeug-Kontrollen (4 Muster)" |
| `make doc-structure` | — | grün | grün — 624 Datei(en), 0 Befund(e) |
| `make trace-check RANGE=HEAD~4..HEAD` | — | grün | grün |

## Negativbefunde

| Bereich | Ergebnis |
|---|---|
| Muster-Deckung der drei belegten Wendungen (state.md@`ecfa2b4`: „Bis slice-NNN stand hier", „bis slice-NNN tat das", „Vorher stand hier") | geprüft, ohne Befund — alle drei stehen wörtlich im `forbid-pattern` |
| Muster-Auszug im Selbsttest (fail-closed: leere-Prüfung → Exit 2) | geprüft, ohne Befund; Grenze: `grep -m1` nimmt nur das erste der drei identischen Muster — divergieren sie, wird nur das erste getestet |
| Scoping-Verhalten des echten Bestands (Chronik im Slice-Plan) | geprüft, ohne Befund — gegen die drei echten Regeln grün (Probe 3); die Selbsttest-Kontrolle pinnt es nur nicht (F-5) |
| Vierte Commit im Range (`72bf56d`, Archivierung slice-201) | geprüft, ohne Befund — Stub-Form, Archiv-Zip, Report-Wegzug folgen `AGENTS.md` §6 |
| Register-Form nach Closure: `state.md` trägt Zustand + Anker, keine Chronik | geprüft, ohne Befund — die bewachte Regel hält der Bestand selbst ein |
| Commit-Traceability über den Range (jede Message trägt `slice-NNN`/`AC-*`) | geprüft, ohne Befund — `make trace-check` grün |

## Summary

| Kategorie | Anzahl |
|---|---|
| HIGH | 4 |
| MEDIUM | 1 |
| LOW | 4 |
| INFO | 1 |

**Finding-Klassen dieses Laufs:** Attestierung vor dem Vorgang · Probe
liefert den Gegenstand mit · Beleg verweist auf nicht vorhandenen Inhalt ·
Zählung divergiert vom Zähllauf · Nachzug fehlt in Aufzählung · Chronik in
lebenden Dateien · Dokument-interner Widerspruch · Plan-Sektion
unausgefüllt · Fallvariante entkommt Muster

## Verdikt

**Merge-blockierend:** ja — die vier HIGH-Findings treffen die
Closure-Attestierung (F-1), den Beleg der Zitat-Kontrolle (F-2), den
DoD-Punkt zur Sensor-Doku (F-3) und die Zählung in Gate-Index und
Sensor-Doku (F-4). Der Sensor selbst funktioniert (Proben 1, 2b, 3, 4, 7
rot/grün wie behauptet); gebrochen sind der Selbstbeweis der Zitat-Kontrolle
und die Dokumentation der Grenze und Menge — genau die Schichten, die der
Slice als Lerneintrag verkörpern wollte. Der Risiko-Ausgang §7 „die Grenze
steht am Sensor selbst" ist in der Halbwahrheit zu revidieren, bevor der
Slice nach `done/` geht.

**Übergabe:** Findings an den Implementer; die Finding-Klassen gehen
zusätzlich in die Slice-Closure §7 — F-1 ist die vierte Auflage von
`BEO-GATE/attestierung-vor-dem-vorgang` (Schwelle überschritten, Ausgang
weisen), F-2/F-5 die vierte und fünfte von
`BEO-GATE/probe-liefert-den-gegenstand-mit` (ebenso).
