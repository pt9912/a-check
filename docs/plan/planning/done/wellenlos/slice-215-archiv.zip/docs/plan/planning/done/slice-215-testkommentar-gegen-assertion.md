# slice-215 — Regel: ein Testkommentar sagt nicht mehr zu, als seine Assertion prüft

**Lifecycle:** Der Zustand dieses Slice ist das Verzeichnis, in dem diese
Datei liegt — eines von `open/`, `next/`, `in-progress/`, `done/`. Er
wechselt nur durch `git mv` (`make slice-mv`).

**Welle:** ohne Welle — die Closure-Bedingung wäre die eigene DoD.

**Bezug:** 3. und 4. Auflage von
[`BEO-GATE/testbeschreibung-weiter-als-assertion`](../observations/BEO-GATE/testbeschreibung-weiter-als-assertion/observation.md)
(slice-210, slice-211, slice-213, slice-214) — Ausgang *geplant* mit diesem Slice.

**Berührte Spec-Stellen:** — · Der Slice berührt kein Spec-Stratum.

**Verantwortlich:** Claude — gesetzt beim Übergang nach `next/` (Maintainer: „machen wir weiter“, 2026-10-07).

**Autor:** Claude. **Datum:** 2026-10-07.

**Lerneintrag — Form:** geschärfte Regel.

---

## 1. Ziel und Abgrenzung

**Ziel:** Die Klasse „ein Testkommentar sagt eine Eigenschaft zu, die keine Assertion prüft"
wird als Regel verkörpert, an die sich bindet, wer einen Test schreibt — als vierte Mess-Regel
neben „eine Mutations-Probe belegt erst, wenn sie rot war" in
[`harness/rules/mess-regeln.md`](../../../../harness/rules/mess-regeln.md), samt Herleitung im
Reviewer-Skill.

**Plan-Änderung 2026-10-07 (vor der Arbeit):** Die Zahl „drei Mess-Regeln“ steht auch in
[`AGENTS.md`](../../../../AGENTS.md) §5 Zeile 15 und im Titel der Regel-Datei; der Kopf von
§Mess-Regeln im Reviewer-Skill zählt „zwei“ und verortet die Zusage in `AGENTS.md` §5, obwohl sie
seit slice-201 in der Regel-Datei steht. Beides zieht dieser Slice mit nach — eine vierte Regel,
neben der „drei“ stehen bleibt, wäre die Aufzählungs-Drift, die die Regel selbst meidet. Ein
CHANGELOG-Eintrag entfällt: [`AGENTS.md`](../../../../AGENTS.md) §6 Schritt 7 nennt den
**öffentlichen Vertrag**; Mess-Regeln binden den Harness-Lauf, nicht den Konsumenten des
Werkzeugs.

**Plan-Änderung 2026-10-07 (Review F-7, vor dem Fix):** Dieselbe alte Verortung steht in den
`Stand:`-Zeilen der drei Register-Einträge der Regeln 1–3
(`BEO-PLAN/review-geltungsbereich-zu-eng`, `BEO-GATE/probe-liefert-den-gegenstand-mit`,
`BEO-PLAN/kandidaten-klassifikation-groeber-als-der-kandidat`) — ihr Zielort `AGENTS.md` §5 trägt
die Herkunfts-Anker nicht mehr. Die drei `Stand:`-Zeilen ziehen auf die Regel-Datei; der übrige
Text der Einträge bleibt.

**Ausdrücklich NICHT in diesem Slice** — je Punkt mit Begründung:

- **Ein Sensor.** *Bestand bleibt bewusst stehen*: ob ein Kommentar mehr behauptet als seine
  Assertion prüft, ist ein Urteil über den Text (AGENTS §3.7) — dieselbe Grenze wie bei den drei
  bestehenden Mess-Regeln.
- **Nachzug alter Testkommentare.** *Ein anderer Vorgang*: die vier Fälle sind behoben; ein
  Durchgang über den ganzen Testbestand wäre eine Kampagne, kein Regel-Slice.

## 2. Definition of Done

- [x] Vierte Mess-Regel in `harness/rules/mess-regeln.md` (Wortlaut seit Review F-5: für jede
      Eigenschaft, die ein Testkommentar nennt, steht eine Assertion, die sie prüft; eine Mutation,
      die genau diese Eigenschaft bricht, macht den Test rot) mit Herkunfts-Anker `seit slice-215`.
- [x] Herleitung mit den vier Fällen im Reviewer-Skill §Mess-Regeln; Register-Stand *verkörpert*.
- [x] Unabhängiger Review, Report unter [`docs/reviews/`](../../../reviews/README.md).
- [x] Closure-Notiz mit Steering-Loop-Lerneintrag.
- [x] Beobachtungs-Register fortgeschrieben (oder „keine Beobachtung" notiert).
- [x] Jedes Risiko aus §6 trägt einen Ausgang.

`make gates` und `make verify` grün.

## 3. Plan (vor Code)

| Datei / Komponente | Änderungs-Art | Begründung |
|---|---|---|
| `harness/rules/mess-regeln.md` | update | vierte Regel |
| `.harness/skills/reviewer.md` | update | Herleitung, damit der Review sie prüft; Kopf zählt und verortet richtig |
| `AGENTS.md` §5 Zeile 15 | update | Zahl der Mess-Regeln |
| `docs/plan/planning/observations/BEO-GATE/testbeschreibung-weiter-als-assertion/state.md` | update | Ausgang *verkörpert* mit Herkunfts-Anker |

## 4. Trigger

**Start** (`open` → `in-progress`): WIP-Limit frei.

**Rückführungen:** `in-progress` → `next` (zu groß): entfällt — eine Regel samt Herleitung.
`in-progress` → `open` (blockiert): entfällt.

## 5. Closure-Trigger

DoD vollständig, `make gates` und `make verify` grün, Closure-Notiz mit Lerneintrag.

## 6. Risiken und offene Punkte

- **Prosa ohne Wirkung:** eine vierte Mess-Regel wird gelesen wie die anderen drei — oder nicht.
  — **Ausgang:** *weiter offen* — getragen vom Beobachtungs-Register: ob die Regel wirkt, zeigt
  erst ein Testkommentar, der nach ihr geschrieben wird. Ein neuer Beleg unter
  `BEO-GATE/testbeschreibung-weiter-als-assertion` nach slice-215 ist genau dieser Fall.

## 7. Closure-Notiz

**Lerneintrag — Form: geschärfte Regel.** Viermal sagte ein Testkommentar eine Eigenschaft zu,
die keine Assertion prüfte. Die Regel steht jetzt als vierte Mess-Regel in
[`harness/rules/mess-regeln.md`](../../../../harness/rules/mess-regeln.md) (`seit slice-215`),
die Herleitung mit drei Ausprägungen im Reviewer-Skill §Mess-Regeln. Kein Sensor: ob ein Kommentar
mehr behauptet, als seine Assertion prüft, ist ein Urteil über Text.

**Geliefert:** Regel 4, Herleitung, Zählstellen nachgezogen ([`AGENTS.md`](../../../../AGENTS.md)
§5 Zeile 15, Titel der Regel-Datei, Kopf des Skill-Abschnitts samt Verortung der Zusage); die
`Stand:`-Zeilen der drei Geschwister-Einträge zeigen auf die Regel-Datei statt auf `AGENTS.md` §5.

**Was hat funktioniert:** Die zweite Zählung (Mess-Regel 3) im Review fand die vierte Zählstelle
im Skill-Kopf — nur die Suche nach Zahlwörtern traf sie, die Wortsuche nicht.

**Was ging anders als geplant:** Der erste Wurf der Herleitung trug genau den Fehler, den die
Regel beschreibt: „je drei Fälle“ für zwei Belege, von denen einer einen hatte, und ein Zitat, das
keines war. Und die Verortung „Zusage in `AGENTS.md` §5“ war seit der Auslagerung der Regeln an
vier Stellen stehen geblieben; drei davon fand erst der Review (Plan-Änderung F-7). Die
Umschreibung zu slice-210 nennt nur die Zeichenketten-Hälfte der damaligen Zusage (Delta-Review
D-2, INFO) — enger als der Beleg, nicht falsch.

**Steering-Loop-Eintrag:** geschärfte Regel — liegt in
[`harness/rules/mess-regeln.md`](../../../../harness/rules/mess-regeln.md) Regel 4 (`seit slice-215`).

**Beobachtungs-Register (`../observations/`):** `BEO-GATE/testbeschreibung-weiter-als-assertion`
→ *verkörpert* (4×, kein neuer Beleg durch diesen Slice — er schreibt keinen Test).
`BEO-HARNESS/verortung-nach-auslagerung-stehen-geblieben` neu (1×).

**Folge-Slices:** keine.

**Risiken aus §6:** das eine Risiko trägt seinen Ausgang (*weiter offen*, Beobachtungs-Register).

**Drei Paarungen:** Anker — `seit slice-215` steht im Zielort der Regel-Datei und im Skill;
die drei Geschwister-Zielorte tragen `seit slice-179/181/193` · Folge-Slice — keiner · Register —
beide genannten Pfade existieren mit nicht leerem `evidence/`.

**Trigger-Audit der aktiven MR:** [`MR-016`](../../../../harness/conventions.md#mr-016) [`MR-019`](../../../../harness/conventions.md#mr-019) [`MR-025`](../../../../harness/conventions.md#mr-025) [`MR-027`](../../../../harness/conventions.md#mr-027) [`MR-028`](../../../../harness/conventions.md#mr-028) [`MR-029`](../../../../harness/conventions.md#mr-029) [`MR-030`](../../../../harness/conventions.md#mr-030) — 0 offen (geprüft 2026-10-07).

## 8. Sub-Area-Prüfungen und Modus-Begründung

**Vorgelagert — Sub-Area-Wahl prüfen:** `HARNESS` (Achsen 1, 2, 3 ✓).

**Vorgelagert — offene Beobachtungen sichten** (2026-10-07):
`BEO-GATE/testbeschreibung-weiter-als-assertion` (4×) ist dieser Slice selbst. Der vierte
Beleg kam vor der Verkörperung — die Prosa-Form ist damit nicht ausgeschöpft, sondern noch nicht
geschrieben; ein Sensor bleibt ausgeschlossen (§1). Weitere Treffer in `HARNESS`: keine offenen
Einträge, die dieser Slice berührt.

**Modus-Begründungsblock:** alle berührten Sub-Areas GF.
